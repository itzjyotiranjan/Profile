const blacklist = ["renovate-bot", "technote-space", "sw-yx"];

export { blacklist };
export default blacklist;
